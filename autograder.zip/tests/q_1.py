OK_FORMAT = True

test = {   'name': 'q_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> type(hola_mundo) == str\nTrue', 'hidden': False, 'locked': False, 'points': 1, 'success_message': 'Good job!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
